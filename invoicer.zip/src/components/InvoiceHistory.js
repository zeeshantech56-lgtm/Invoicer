// src/components/InvoiceHistory.js
// Live list of the logged-in shop's invoices from the last 30 days only.

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { subscribeToShopInvoices, RETENTION_DAYS } from "@/lib/invoices";

export default function InvoiceHistory() {
  const { user } = useAuth();
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const unsubscribe = subscribeToShopInvoices(user.uid, (data) => {
      setInvoices(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [user]);

  const formatDate = (timestamp) => {
    if (!timestamp?.toDate) return "Just now";
    return timestamp.toDate().toLocaleString();
  };

  return (
    <div className="border border-gray-200 rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">
          Recent transactions
        </h2>
        <span className="text-xs text-gray-400">Last {RETENTION_DAYS} days</span>
      </div>

      {loading ? (
        <p className="text-sm text-gray-400">Loading...</p>
      ) : invoices.length === 0 ? (
        <p className="text-sm text-gray-400">No invoices yet. Create your first one.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-left text-gray-500 text-xs uppercase">
                <th className="pb-2 pr-4">Customer</th>
                <th className="pb-2 pr-4">Items</th>
                <th className="pb-2 pr-4">Total</th>
                <th className="pb-2 pr-4">Date</th>
                <th className="pb-2">Link</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv) => (
                <tr key={inv.id} className="border-b border-gray-100">
                  <td className="py-2 pr-4 font-medium text-gray-900">
                    {inv.customerName}
                  </td>
                  <td className="py-2 pr-4 text-gray-600 max-w-xs truncate">
                    {(inv.products || []).map((p) => `${p.qty}x ${p.name}`).join(", ")}
                  </td>
                  <td className="py-2 pr-4 text-gray-900 font-medium">
                    ₹{Number(inv.total || 0).toFixed(2)}
                  </td>
                  <td className="py-2 pr-4 text-gray-500 text-xs">
                    {formatDate(inv.timestamp)}
                  </td>
                  <td className="py-2">
                    <Link
                      href={`/invoice/${inv.id}`}
                      target="_blank"
                      className="text-xs text-blue-600 underline"
                    >
                      View
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
