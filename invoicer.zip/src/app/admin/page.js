// src/app/admin/page.js
// Admin-only panel. Access gated two ways:
//  1. UI: ProtectedRoute redirects anyone whose email != ADMIN_EMAIL
//  2. DATA: Firestore rules only let ADMIN_EMAIL's UID read the full
//     "users" collection and all invoices with no date limit.
// Both must agree, or a locked-out admin can't see data even past the UI gate.

"use client";

import { useEffect, useState, useMemo } from "react";
import { collection, getDocs } from "firebase/firestore";
import { signOut } from "firebase/auth";
import { db, auth } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { subscribeToAllInvoices } from "@/lib/invoices";
import ProtectedRoute from "@/components/ProtectedRoute";
import Logo from "@/components/Logo";
import Link from "next/link";

function AdminContent() {
  const { user } = useAuth();
  const [shops, setShops] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const fetchShops = async () => {
      const snap = await getDocs(collection(db, "users"));
      setShops(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    };
    fetchShops();

    const unsubscribe = subscribeToAllInvoices((data) => {
      setInvoices(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const shopNameById = useMemo(() => {
    const map = {};
    shops.forEach((s) => (map[s.id] = s.shopName));
    return map;
  }, [shops]);

  const invoicesByShop = useMemo(() => {
    const map = {};
    invoices.forEach((inv) => {
      map[inv.shopId] = (map[inv.shopId] || 0) + 1;
    });
    return map;
  }, [invoices]);

  const revenueByShop = useMemo(() => {
    const map = {};
    invoices.forEach((inv) => {
      map[inv.shopId] = (map[inv.shopId] || 0) + Number(inv.total || 0);
    });
    return map;
  }, [invoices]);

  const filteredInvoices = invoices.filter((inv) => {
    const q = search.toLowerCase();
    return (
      inv.customerName?.toLowerCase().includes(q) ||
      inv.shopName?.toLowerCase().includes(q) ||
      inv.customerPhone?.includes(q)
    );
  });

  const totalRevenue = invoices.reduce((sum, inv) => sum + Number(inv.total || 0), 0);

  const handleLogout = async () => {
    await signOut(auth);
  };

  const formatDate = (timestamp) => {
    if (!timestamp?.toDate) return "Just now";
    return timestamp.toDate().toLocaleString();
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Logo size="sm" />
          <span className="text-xs bg-gray-900 text-white px-2 py-0.5 rounded uppercase tracking-wide">
            Admin
          </span>
        </div>
        <div className="flex items-center gap-4">
          <Link
            href="/dashboard"
            className="text-sm text-gray-600 border border-gray-300 rounded px-3 py-1.5 hover:bg-gray-50"
          >
            My dashboard
          </Link>
          <p className="text-sm text-gray-500">{user?.email}</p>
          <button
            onClick={handleLogout}
            className="text-sm text-gray-600 border border-gray-300 rounded px-3 py-1.5 hover:bg-gray-50"
          >
            Sign out
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8">
        {/* Stat cards */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-8">
          <StatCard label="Total shops" value={shops.length} />
          <StatCard label="Total invoices" value={invoices.length} />
          <StatCard label="Total revenue" value={`₹${totalRevenue.toFixed(2)}`} />
          <StatCard
            label="Active shops (sent ≥1 invoice)"
            value={Object.keys(invoicesByShop).length}
          />
        </div>

        {/* Shops table */}
        <div className="border border-gray-200 rounded-lg p-6 mb-8">
          <h2 className="text-sm font-semibold text-gray-900 uppercase tracking-wide mb-4">
            All shops
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 text-left text-gray-500 text-xs uppercase">
                  <th className="pb-2 pr-4">Shop name</th>
                  <th className="pb-2 pr-4">Email</th>
                  <th className="pb-2 pr-4">Invoices sent</th>
                  <th className="pb-2 pr-4">Revenue</th>
                  <th className="pb-2">Joined</th>
                </tr>
              </thead>
              <tbody>
                {shops.map((shop) => (
                  <tr key={shop.id} className="border-b border-gray-100">
                    <td className="py-2 pr-4 font-medium text-gray-900">{shop.shopName}</td>
                    <td className="py-2 pr-4 text-gray-600">{shop.email}</td>
                    <td className="py-2 pr-4 text-gray-600">{invoicesByShop[shop.id] || 0}</td>
                    <td className="py-2 pr-4 text-gray-900">
                      ₹{(revenueByShop[shop.id] || 0).toFixed(2)}
                    </td>
                    <td className="py-2 text-gray-500 text-xs">{formatDate(shop.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* All invoices, unrestricted by date */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">
              All invoices (no date limit)
            </h2>
            <input
              type="text"
              placeholder="Search customer, shop, phone..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="border border-gray-300 rounded px-3 py-1.5 text-sm w-64 focus:outline-none focus:ring-2 focus:ring-gray-900"
            />
          </div>

          {loading ? (
            <p className="text-sm text-gray-400">Loading...</p>
          ) : (
            <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-white">
                  <tr className="border-b border-gray-200 text-left text-gray-500 text-xs uppercase">
                    <th className="pb-2 pr-4">Shop</th>
                    <th className="pb-2 pr-4">Customer</th>
                    <th className="pb-2 pr-4">Phone</th>
                    <th className="pb-2 pr-4">Total</th>
                    <th className="pb-2 pr-4">Date</th>
                    <th className="pb-2">Link</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredInvoices.map((inv) => (
                    <tr key={inv.id} className="border-b border-gray-100">
                      <td className="py-2 pr-4 text-gray-600">
                        {inv.shopName || shopNameById[inv.shopId]}
                      </td>
                      <td className="py-2 pr-4 font-medium text-gray-900">
                        {inv.customerName}
                      </td>
                      <td className="py-2 pr-4 text-gray-600">{inv.customerPhone}</td>
                      <td className="py-2 pr-4 text-gray-900">
                        ₹{Number(inv.total || 0).toFixed(2)}
                      </td>
                      <td className="py-2 pr-4 text-gray-500 text-xs">
                        {formatDate(inv.timestamp)}
                      </td>
                      <td className="py-2">
                        <Link
                          href={`/invoice/${inv.id}`}
                          target="_blank"
                          className="text-xs text-blue-600 underline"
                        >
                          View
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <p className="text-xs text-gray-500 mb-1">{label}</p>
      <p className="text-2xl font-semibold text-gray-900">{value}</p>
    </div>
  );
}

export default function AdminPage() {
  return (
    <ProtectedRoute adminOnly>
      <AdminContent />
    </ProtectedRoute>
  );
}
