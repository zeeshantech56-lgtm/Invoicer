// src/app/page.js
// Public marketing landing page. No auth required.

import Link from "next/link";
import Logo from "@/components/Logo";

const features = [
  {
    title: "Invoice in seconds",
    desc: "Add products, quantities, and prices — the total calculates itself. Built for checkout-counter speed.",
  },
  {
    title: "WhatsApp delivery",
    desc: "Every invoice sends straight to the customer's WhatsApp, pre-filled and ready — no typing required.",
  },
  {
    title: "Shareable invoice link",
    desc: "Each message includes a link to a clean, permanent invoice page your customer can revisit anytime.",
  },
  {
    title: "Your data, isolated",
    desc: "Every shop's invoices are private by default. You only ever see your own customers and history.",
  },
  {
    title: "30 days of history",
    desc: "Your dashboard keeps the last 30 days of transactions instantly searchable and exportable.",
  },
  {
    title: "Free to run",
    desc: "Built on free-tier infrastructure — no card required, no hidden usage fees for small shops.",
  },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      {/* Nav */}
      <nav className="border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Logo />
          <div className="flex items-center gap-3">
            <Link
              href="/login"
              className="text-sm font-medium text-gray-600 hover:text-gray-900"
            >
              Sign in
            </Link>
            <Link
              href="/login?signup=1"
              className="text-sm font-medium bg-gray-900 text-white px-4 py-2 rounded-md hover:bg-gray-800"
            >
              Get started free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-4xl mx-auto px-6 pt-20 pb-16 text-center">
        <h1 className="text-4xl sm:text-5xl font-semibold tracking-tight text-gray-900 leading-tight">
          Invoice customers.
          <br />
          Send it on WhatsApp. Done.
        </h1>
        <p className="mt-5 text-lg text-gray-500 max-w-2xl mx-auto">
          Invoicer gives every shop owner their own dashboard to bill customers
          and deliver invoices instantly over WhatsApp — with a shareable link
          the customer can always come back to.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3">
          <Link
            href="/login?signup=1"
            className="bg-gray-900 text-white px-6 py-3 rounded-md text-sm font-medium hover:bg-gray-800"
          >
            Create your shop account
          </Link>
          <Link
            href="/login"
            className="border border-gray-300 px-6 py-3 rounded-md text-sm font-medium hover:bg-gray-50"
          >
            Sign in
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 py-16 border-t border-gray-100">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((f) => (
            <div key={f.title}>
              <h3 className="text-base font-semibold text-gray-900 mb-1.5">
                {f.title}
              </h3>
              <p className="text-sm text-gray-500 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA footer */}
      <section className="border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-6 py-16 text-center">
          <h2 className="text-2xl font-semibold text-gray-900">
            Set up your shop in under a minute
          </h2>
          <p className="mt-2 text-sm text-gray-500">
            No credit card. No setup fee. Just your email and shop name.
          </p>
          <Link
            href="/login?signup=1"
            className="mt-6 inline-block bg-gray-900 text-white px-6 py-3 rounded-md text-sm font-medium hover:bg-gray-800"
          >
            Get started free
          </Link>
        </div>
      </section>

      <footer className="border-t border-gray-100 py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between text-xs text-gray-400">
          <span>© {new Date().getFullYear()} Invoicer</span>
          <span>Built for small shops</span>
        </div>
      </footer>
    </div>
  );
}
